module Bootstrap
  VERSION = '3.1.0.0'
  BOOTSTRAP_SHA = '1409cde7e800ca83fd761f87e5ad8f0d259e38d1'
end
